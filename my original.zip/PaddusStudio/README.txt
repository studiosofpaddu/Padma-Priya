# Paddu's Studio — beginner website starter

This is a mobile-friendly starter website with:
- Brand introduction, creations, Our Story and How to Order
- Sample product catalogue with prices and categories
- Customization notice on every product
- Order form with customer name, phone, delivery address and customization notes
- WhatsApp order message (customer must press Send in WhatsApp)
- Clear no-COD and shipping-confirmation notices
- A demo product manager

## Important limitations of this starter

The demo product manager uses browser local storage. Changes are saved only in the browser and device where you make them. It is NOT a shared online admin system, the demo PIN is not secure, and edits will not automatically appear for customers on their devices. Do not use it to store sensitive customer data.

To meet the final requirement (secure admin login from your phone, with product/photo/price edits syncing live for all visitors), connect a shared backend such as Supabase or another suitable service. The website hosting can be free, but no provider can guarantee that free hosting/database tiers will remain free forever; limits and terms can change.

## Try it on your computer
1. Extract the ZIP file.
2. Open `index.html` in Chrome or Edge.
3. Open the “Studio product manager (demo)” section near the bottom.
4. Enter your WhatsApp number in international format, digits only. For India, use `91` followed by the 10-digit number, e.g. `919876543210` (replace with your own number).
5. Click “Save settings on this device”.
6. Add/edit sample products and try the order form.

The sample products and prices are examples. Replace them with your real product details. For best image results, upload your photos to a proper online image storage service and use their image URLs.

## Publish a static version free with GitHub Pages
1. Create/sign in to a GitHub account at https://github.com/
2. Create a new public repository, for example `paddus-studio`.
3. Upload `index.html` to the repository root.
4. In the repository, open **Settings → Pages**.
5. Under build/deployment, choose **Deploy from a branch**, select `main` and `/ (root)`, then Save.
6. Wait for GitHub Pages to publish the site. GitHub will show the live URL in Settings → Pages; open that URL on your phone.

Publishing this starter does not create a secure, shared admin panel. For that, a shared database and proper authentication must be configured before the website is used as a real business store. The WhatsApp number must be configured and tested after publishing; browser local-storage settings from your computer do not transfer to your phone or the public website.
